README FILE


The Writing Blocks apps (both APK file and PC application) are stored in the APP folder.

To test the app, run the "writing blocks.exe" application for the PC version.
For the mobile app version, transfer the "final year project app" APK file to an Android phone.

All forms and copies of the thesis can be found in the THESIS folder.

All project assets used to develop the app are in the UNITY PROJECT folder.

Google Drive Link:https://drive.google.com/open?id=1zuftrvFZAIiK3yQg33F3eMK5w9b7supj

Github Link:https://github.com/jt17196/finalyearproject